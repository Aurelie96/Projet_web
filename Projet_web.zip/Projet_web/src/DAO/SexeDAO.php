<?php

namespace Projet_web\DAO;

use Projet_web\Domain\Sexe;

class SexeDAO extends DAO
{

}