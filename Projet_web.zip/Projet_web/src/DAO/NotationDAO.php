<?php

namespace Projet_web\DAO;

use Projet_web\Domain\Notation;

class NotationDAO extends DAO
{

}