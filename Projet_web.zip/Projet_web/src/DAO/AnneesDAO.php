<?php

namespace Projet_web\DAO;

use Projet_web\Domain\Annees;

class AnneesDAO extends DAO
{

}