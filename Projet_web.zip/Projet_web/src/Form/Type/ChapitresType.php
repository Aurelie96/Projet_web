<?php

namespace Projet_web\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Projet_web\DAO\NiveauxDAO;

class ChapitresType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('titreNiveau', 'text')
            ->add('idNiveau', 'choice', array(
                'choices' => array(
                    null => '-- Sélectionner une Classe --',
                    1 => '6ème A',
                    2 => '6ème B',
                    3 => '5ème A',
                    4 => '5ème B',
                    5 => '4ème A',
                    6 => '4ème B',
                    7 => '3ème A',
                    8 => '3ème B')
            ));
    }

    public function getName()
    {
        return 'user';
    }

}
